from flask import Flask, render_template, jsonify, request, Response, url_for, redirect
import pandas as pd
import webbrowser
import random
import time
import os
from datetime import datetime
app = Flask(__name__)

@app.route('/')
def index():
  return render_template('index.html')


@app.route('/funding-allocation/', methods=['GET','POST'])
def funding_allocation():

  if 'submit_button3' in request.form:
      if request.method == 'POST':
          f = request.files['file']
          f.save(f.filename)
          return render_template('index.html', result=None)

  if 'submit_button1' in request.form or 'submit_button2' in request.form:
      #print ('Model run.')
      then = time.time()  # Time before the operations start

      # 'AggDataNew200wFeasEqtPtBTier.csv'
      ###Input stop file and budget
      if os.path.exists("input.csv"):
          df = pd.read_csv("input.csv")
      else:
          #df=pd.read_csv('AggDataNew200wFeasEqtPtBTier.csv')
          print("No file found")
      budget1 = 5000000
      # Data pre-processing

      # MARTA Stop Data
      Stops1 = df['StopAbbr'].tolist()
      ridership1 = df['Ons_Dec19'].tolist()
      numStops1 = len(df['StopAbbr'].tolist())
      n1 = range(numStops1)

      # NSA Demographic Data
      avgincome1 = df['NSAInc'].tolist()
      nocar1 = df['NSANoCar'].tolist()
      population1 = df['NSAPop'].tolist()

      # Unsolvable Observations
      poss1 = df['PossibiltyOfAmentity'].tolist()

      # Simulated ROW  ##(simulated to real when data is available)
      row = [0] * numStops1
      for n in range(numStops1):
          x = random.random()
          if x > .5:
              row[n] = int(random.randint(20000, 40000))

      # Setting equity weights
      incomeweight = 0.25
      nocarweight = 0.5
      populationweight = 0.25
      # Existing amenity score calculation
      amenityscore = []
      for i in n1:
          if poss1[i] == 0:
              amenityscore.append(0)
          else:
              if df['BASE'].tolist()[i] == 'DIRT' and df['Stop_Type'].tolist()[i] == 'Sign':
                  amenityscore.append(1)
              elif (df['BASE'].tolist()[i] == 'CONC' and df['Stop_Type'].tolist()[i] == 'Sign'):
                  amenityscore.append(2)
              elif df['Stop_Type'].tolist()[i] == 'MARTA Bench' or df['Stop_Type'].tolist()[i] == 'Other Bench' or \
                      df['Stop_Type'].tolist()[i] == 'Simme Seat':
                  amenityscore.append(3)
              elif (df['Stop_Type'].tolist()[i] == 'MARTA Shelter' or df['Stop_Type'].tolist()[i] == 'Other Shelter') and \
                      df['ADA_ACCESS'].tolist()[i] != 'Y':
                  amenityscore.append(4)
              elif (df['Stop_Type'].tolist()[i] == 'MARTA Shelter' or df['Stop_Type'].tolist()[i] == 'Other Shelter') and \
                      df['ADA_ACCESS'].tolist()[i] == 'Y' or df['Stop_Type'].tolist()[i] == 'Station':
                  amenityscore.append(5)
      # Amenity Costs
      simmeseat_cost = 500
      simmeseat_install_np_tc = 5500
      simmeseat_install_sw = 700

      bench_cost = 5000  # survey and design + bench kit
      bench_install_sw = 1000  # installation cost on existing sidewalk
      bench_install_np = 3000  # installation cost on new pad

      shelter_cost = 13000  # survey and design + shelter kit
      shelter_install_sw = 6000  # installation cost on existing sidewalk
      shelter_install_np = 10000  # installation cost on new pad

      # Calculating cost of amenity needs for each stop
      need = [[0, 0, 0] for i in n1]
      for i in n1:
          if amenityscore[i] < 3:
              if df['BASE'].tolist()[i] == 'CONC':
                  ss_cost = simmeseat_cost + simmeseat_install_sw
                  b_cost = bench_cost + bench_install_sw
              else:
                  ss_cost = simmeseat_cost + simmeseat_install_np_tc
                  b_cost = bench_cost + bench_install_np
              need[i][0] = ss_cost
              need[i][1] = b_cost
          if amenityscore[i] < 4:
              if df['BASE'].tolist()[i] == 'CONC':
                  sh_cost = shelter_cost + shelter_install_sw
              else:
                  sh_cost = shelter_cost + shelter_install_np
              need[i][2] = sh_cost

      # Calculation of equity score
      equityscore1 = []
      for i in range(0, len(Stops1)):
          equityscore1.append(incomeweight * (1 - avgincome1[i] / max(avgincome1)) + nocarweight * (
                  nocar1[i] / max(nocar1)) + populationweight * ((population1[i]) / max(population1)))
      # Greedy heuristic
      funding = [0] * numStops1
      fincost = [0] * numStops1
      # indexList=[i[0] for i in sorted(enumerate(equityscore1), key=lambda k: k[1], reverse=True)]
      indexList = [i[0] for i in sorted(enumerate([a * b for a, b in zip(ridership1, equityscore1)]),
                                        key=lambda k: k[1], reverse=True)]

      forvars = [
          # [need vector, unsolvable included, lower acceptable score, upper acceptable score, ROW not included, need position in list]
          [need, False, 0, 4, True, 2],
          [need, False, 0, 4, False, 2],
          [need, False, 0, 3, True, 1],
          [need, False, 0, 3, False, 1],
          [need, True, 0, 3, True, 0],
          [need, True, 0, 3, False, 0]
      ]

      for f in forvars:
          for x in n1:
              s = indexList.index(x)
              if f[0][s][f[5]] > 0 and budget1 >= f[0][s][f[5]] + row[s] and funding[s] == 0 and (
                      f[1] or amenityscore[s] > f[2]) and amenityscore[s] < f[3] and (row[s] != 0 or f[4]):
                  funding[s] = f[0][s][f[5]] + row[s]
                  fincost[s] = f[0][s][f[5]]
                  budget1 -= f[0][s][f[5]] + row[s]


      # Output creation

      print("Solution: ")
      print(funding)
      print(sum(funding))

      # Amenity Recommendation
      amenitytype = []
      for s in n1:
          if fincost[s] == 19000 or fincost[s] == 23000:
              amenitytype.append("Shelter")
          if fincost[s] == 8000 or (fincost[s] == 6000 and df['BASE'].tolist()[s] == 'CONC'):
              amenitytype.append("Bench")
          if fincost[s] == 1200 or (fincost[s] == 6000 and df['BASE'].tolist()[s] != 'CONC'):
              amenitytype.append("Simme Seat")
          if fincost[s] == 0:
              amenitytype.append('None')

      # New amenity score calculation
      newscore = []
      for i in n1:
          if amenitytype[i] == 'Shelter' and df['ADA_ACCESS'].tolist()[i] != 'Y':
              newscore.append(4)
          if amenitytype[i] == 'Shelter' and df['ADA_ACCESS'].tolist()[i] == 'Y':
              newscore.append(5)
          if amenitytype[i] == 'Simme Seat' or amenitytype[i] == 'Bench':
              newscore.append(3)
          if amenitytype[i] == 'None':
              newscore.append(amenityscore[i])

      # Output exporting to CSV

      df2 = pd.DataFrame()
      df2['Stop_ID'] = Stops1
      df2['Funding'] = funding
      df2['Amenity_Type'] = amenitytype
      df2['Current Score'] = amenityscore
      df2['New Score'] = newscore

      priorityList=[0]*numStops1
      count=0
      for n in n1:
          if funding[indexList[n]]!=0:
              count+=1
              priorityList[indexList[n]]=count
      for n in n1:
          if funding[indexList[n]]==0:
              count+=1
              priorityList[indexList[n]]=count
      df2['Priority'] = priorityList

      # df2.to_csv("outputGreedy.csv")

      now = time.time()  # Time after it finished

      print("It took: ", now - then, " seconds")


      if 'submit_button2' in request.form:
          dt = datetime.now().strftime("%m_%d_%Y")
          return Response(
              df2.to_csv(),
              mimetype="text/csv",
              headers={"Content-disposition": "attachment; filename=HeuristicOutput_" + dt + ".csv"})

      if 'submit_button1' in request.form:
          df2.sort_values('Priority').to_html('templates/index2.html')
          #return tbl_fmt.format(''.join(row_fmt.format(k, v) for k, v in df2.to_dict().items()))
          return render_template('index2.html',result=df2.to_dict())
          # return webbrowser.open_new_tab('google.com')

          #return jsonify(df2.to_dict(orient='records'))




#this doesnt work
  if 'reset1' in request.form:
      #print('hi')
      if os.path.exists("input.csv"):
          os.remove("input.csv")
      else:
          print("The file does not exist")
      return render_template('index.html', result=None)

# @app.route('/funding-allocation2/', methods=['GET', 'POST'])
#
# def funding_allocation2():
#   if 'submit_button3' in request.form:
#       if request.method == 'POST':
#           f = request.files['file']
#           f.save(f.filename)
#           return render_template('index.html')

if __name__ == '__main__':
  app.run(debug=True)
